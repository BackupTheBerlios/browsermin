# phpMyAdmin SQL Dump
# version 2.5.6
# http://www.phpmyadmin.net
#
# Host: localhost
# Erstellungszeit: 23. M�rz 2004 um 22:32
# Server Version: 4.0.15
# PHP-Version: 4.3.3
# 
# Datenbank: `browsermin`
# 

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `alias`
#

DROP TABLE IF EXISTS `alias`;
CREATE TABLE `alias` (
  `address` varchar(255) NOT NULL default '',
  `goto` text NOT NULL,
  `domain` varchar(255) NOT NULL default '',
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `active` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`address`),
  KEY `address` (`address`)
) TYPE=MyISAM COMMENT='Postfix Admin - Virtual Aliases';

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `domain`
#

DROP TABLE IF EXISTS `domain`;
CREATE TABLE `domain` (
  `domain` varchar(255) NOT NULL default '',
  `description` varchar(255) NOT NULL default '',
  `aliases` int(10) NOT NULL default '-1',
  `mailboxes` int(10) NOT NULL default '-1',
  `maxquota` int(10) NOT NULL default '-1',
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `active` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`domain`),
  KEY `domain` (`domain`)
) TYPE=MyISAM COMMENT='Postfix Admin - Virtual Domains';

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `mailbox`
#

DROP TABLE IF EXISTS `mailbox`;
CREATE TABLE `mailbox` (
  `username` varchar(255) NOT NULL default '',
  `password` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `maildir` varchar(255) NOT NULL default '',
  `quota` int(10) NOT NULL default '-1',
  `domain` varchar(255) NOT NULL default '',
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `active` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`username`),
  KEY `username` (`username`),
  KEY `password` (`password`),
  KEY `password_2` (`password`),
  KEY `username_2` (`username`),
  FULLTEXT KEY `username_3` (`username`),
  FULLTEXT KEY `username_4` (`username`)
) TYPE=MyISAM COMMENT='Postfix Admin - Virtual Mailboxes';
